
import fs from "node:fs";
import path from "node:path";
import YAML from "yaml";
import _ from "lodash";

type AnyObj = Record<string, any>;

function evalExpr(expr: string, ctx: AnyObj) {
  const helpers = {
    uuid: () => (globalThis.crypto?.randomUUID ? crypto.randomUUID() : (Math.random().toString(16).slice(2)+"-"+Date.now())),
    now: () => new Date().toISOString(),
    nowEpoch: () => Math.floor(Date.now()/1000),
    mapTable: (tablePath: string, value: string) => _.get(ctx.__tables, tablePath, {})[value],
    firstNonNull: (...args: any[]) => args.find(v => v !== undefined && v !== null),
    concat: (...args: any[]) => args.join(""),
    asArray: (x: any) => (Array.isArray(x) ? x : (x == null ? [] : [x])),
    flatten: (arrs: any[]) => [].concat(...arrs),
    uomConvert: {
      weight: (v: any, from: string, to: string) => {
        const w = _.get(ctx.__uom, ["weight", (from||"KG").toUpperCase()], 1);
        const t = _.get(ctx.__uom, ["weight", (to||"KG").toUpperCase()], 1);
        const n = Number(v);
        if (!Number.isFinite(n)) return undefined;
        return n * (w / t);
      },
      length: (v: any, from: string, to: string) => {
        const w = _.get(ctx.__uom, ["length", (from||"CM").toUpperCase()], 1);
        const t = _.get(ctx.__uom, ["length", (to||"CM").toUpperCase()], 1);
        const n = Number(v);
        if (!Number.isFinite(n)) return undefined;
        return n * (w / t);
      }
    }
  };
  const fn = new Function(...Object.keys(helpers), ...Object.keys(ctx.__vars), `return (${expr});`);
  return fn(...Object.values(helpers), ...Object.values(ctx.__vars));
}

function interpolate(value: any, ctx: AnyObj) {
  if (typeof value === "string" && value.includes("${")) {
    return value.replace(/\$\{([^}]+)\}/g, (_: any, expr: string) => {
      try { const r = evalExpr(expr.trim(), ctx); return r==null? "": String(r); }
      catch { return ""; }
    });
  }
  return value;
}

function pickFirstNonNull(paths: any[], data: AnyObj) {
  for (const p of paths) {
    if (p === null || p === undefined) continue;
    if (typeof p === "string" && p.startsWith("$.")) {
      const v = _.get(data, p.slice(2));
      if (v !== undefined && v !== null && !(typeof v === "string" && v.length === 0)) return v;
    } else {
      return p;
    }
  }
  return undefined;
}

function applyMap(nodeMapping: any, data: AnyObj, rootData: AnyObj, ctx: AnyObj) {
  if (nodeMapping == null) return undefined;

  if (typeof nodeMapping === "string") {
    if (nodeMapping.startsWith("$.")) {
      return _.get(data, nodeMapping.slice(2));
    }
    return interpolate(nodeMapping, ctx);
  }

  if (Array.isArray(nodeMapping)) {
    return nodeMapping.map(n => applyMap(n, data, rootData, ctx));
  }

  if (typeof nodeMapping === "object") {
    if ("valueFrom" in nodeMapping) {
      return pickFirstNonNull(nodeMapping.valueFrom, data);
    }
    if ("value" in nodeMapping) {
      const raw = nodeMapping.value;
      if (typeof raw === "string" && raw.startsWith("${")) {
        return evalExpr(raw.slice(2, -1), ctx);
      }
      if (typeof raw === "string" && raw.startsWith("$.")) return _.get(data, raw.slice(2));
      return raw;
    }
    if ("object" in nodeMapping) {
      const obj: AnyObj = {};
      for (const [k, sub] of Object.entries(nodeMapping.object)) {
        const v = applyMap(sub, data, rootData, ctx);
        if (v !== undefined) obj[k] = v;
      }
      return obj;
    }
    if ("arrayOf" in nodeMapping) {
      return nodeMapping.arrayOf.map((el: any) => applyMap(el, data, rootData, ctx));
    }
    if ("mapArray" in nodeMapping) {
      const src = nodeMapping.mapArray.source;
      let arr: any[] = [];
      if (typeof src === "string" && src.startsWith("${")) {
        arr = evalExpr(src.slice(2,-1), ctx);
      } else if (typeof src === "string" && src.startsWith("$.")) {
        arr = _.get(data, src.slice(2)) || [];
      } else if (Array.isArray(src)) {
        arr = src;
      }
      if (!Array.isArray(arr)) arr = [];
      const alias = nodeMapping.mapArray.as || "it";
      return arr.map((item) => {
        const subCtx = {...ctx, __vars: {...ctx.__vars, [alias]: item}};
        return applyMap(nodeMapping.mapArray.mapping, item, rootData, subCtx);
      }).filter(Boolean);
    }
    if ("when" in nodeMapping) {
      const cond = nodeMapping.when;
      let pass = true;
      if (typeof cond === "string" && cond.startsWith("${")) {
        pass = !!evalExpr(cond.slice(2,-1), ctx);
      } else if (typeof cond === "string" && cond.startsWith("$.")) {
        pass = !!_.get(data, cond.slice(2));
      } else {
        pass = !!cond;
      }
      if (pass) {
        const rest = {...nodeMapping};
        delete rest.when;
        return applyMap(rest, data, rootData, ctx);
      }
      return undefined;
    }
    const out: AnyObj = {};
    for (const [k, v] of Object.entries(nodeMapping)) {
      const merge = k.endsWith("@merge");
      const key = merge ? k.replace("@merge","") : k;
      const mapped = applyMap(v, data, rootData, ctx);
      if (mapped === undefined) continue;
      if (merge && typeof mapped === "object" && !Array.isArray(mapped)) {
        out[key] = {...(out[key]||{}), ...mapped};
      } else {
        out[key] = mapped;
      }
    }
    return out;
  }
  return undefined;
}

export function runMapping(mappingYamlPath: string, input: AnyObj, tables: AnyObj = {}, uom: AnyObj = {}) {
  const raw = fs.readFileSync(mappingYamlPath, "utf8");
  const doc = YAML.parse(raw);

  const baseDir = path.dirname(mappingYamlPath)
  const includes = (doc.meta && doc.meta.includes) || [];
  const __tables: AnyObj = {};
  let __uom: AnyObj = uom;

  for (const inc of includes) {
    const p = path.resolve(baseDir, inc);
    const content = fs.readFileSync(p, "utf8");
    const incDoc = YAML.parse(content);
    if (incDoc.status) Object.assign(__tables, incDoc);
    if (incDoc.uom) __uom = incDoc.uom;
  }

  const ctx = { __vars: { $: input }, __tables, __uom };
  const rootSel = (doc.selectors && doc.selectors.root) || "$";
  const rootData = rootSel.startsWith("$.") ? _.get(input, rootSel.slice(2)) : input;
  const result = applyMap(doc.mappings, rootData, input, ctx);
  return result;
}
