
import fs from "node:fs";
import path from "node:path";
import { runMapping } from "./engine/mappingEngine.js";
import Ajv from "ajv";
import addFormats from "ajv-formats";

const inputPath = process.env.INPUT || "examples/orderRelease.sample.json";
const mapPath = process.env.MAP || "mappings/bydm→canonical/order_release_to_canonical_order.yaml";
const schemaPath = process.env.SCHEMA || "schemas/canonical/order.schema.json";

const input = JSON.parse(fs.readFileSync(path.resolve(inputPath), "utf8"));
const out = runMapping(path.resolve(mapPath), input);

const ajv = new Ajv({allErrors:true, strict:false});
addFormats(ajv);
const schema = JSON.parse(fs.readFileSync(path.resolve(schemaPath), "utf8"));
const validate = ajv.compile(schema);
if (!validate(out)) {
  console.error("Schema validation failed:", validate.errors);
  process.exit(1);
}
console.log(JSON.stringify(out, null, 2));
