
import fs from "node:fs";
import path from "node:path";
import Ajv from "ajv";
import addFormats from "ajv-formats";

const ajv = new Ajv({allErrors:true, strict:false});
addFormats(ajv);

const schemaDir = "schemas/canonical";
const files = fs.readdirSync(schemaDir).filter(f => f.endsWith(".json"));
for (const f of files) {
  const schema = JSON.parse(fs.readFileSync(path.join(schemaDir, f), "utf8"));
  const validate = ajv.compile(schema);
  console.log(`Schema OK: ${f}`);
}
