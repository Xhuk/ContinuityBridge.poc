// mappers/common.ts
// Shared helpers and placeholder mapping tables for BYDM → Canonical
export type CanonicalOrder = {
  schemaVersion: "1.0";
  messageId: string;
  eventType: "order.created" | "order.updated";
  occurredAt: string;
  sourceSystem?: string;
  order: {
    orderId: string;
    status: string;
    currency?: string;
    totalAmount?: number;
    buyer?: { id?: string; email?: string; taxId?: string };
    shipping?: {
      service?: string;
      address?: {
        name?: string; line1?: string; city?: string; state?: string;
        postalCode?: string; country?: string;
      };
    };
    items: Array<{
      sku: string; qty: number;
      price?: number; asinOrMeliId?: string;
    }>;
    marketplace?: { channel?: string; site?: string };
  };
  trace?: Record<string, unknown>;
};

export type CanonicalShipment = {
  schemaVersion: "1.0";
  messageId: string;
  eventType: "shipment.created" | "shipment.updated" | "shipment.status";
  occurredAt: string;
  sourceSystem?: string;
  shipment: {
    shipmentId: string;
    orderId?: string;
    status: string;
    tracking?: { carrier?: string; code?: string; url?: string };
    packages?: Array<{
      packageId?: string;
      weightKg?: number;
      dimensionsCm?: { l?: number; w?: number; h?: number };
    }>;
    labels?: Array<{ type?: string; href?: string }>;
  };
  trace?: Record<string, unknown>;
};

export type CanonicalInbound = {
  schemaVersion: "1.0";
  messageId: string;
  eventType: "inbound.created" | "inbound.received" | "inbound.discrepancy";
  occurredAt: string;
  sourceSystem?: string;
  inbound: {
    shipmentId: string;
    reference?: string;
    warehouse?: { code?: string };
    logisticUnits: Array<{
      luId?: string;
      lineItems: Array<{ sku: string; qty: number; lot?: string; expiryDate?: string }>;
    }>;
  };
  trace?: Record<string, unknown>;
};

// --- Mapping tables (fill with your own values) -----------------
export const StatusMap = {
  // BYDM/WMS → Canonical
  order: {
    OPEN: "created",
    ALLOCATED: "allocated",
    PICKED: "picked",
    SHIPPED: "shipped",
    DELIVERED: "delivered",
    CANCELLED: "cancelled"
  } as Record<string, string>,
  shipment: {
    PLANNED: "planned",
    READY_TO_SHIP: "ready_to_ship",
    IN_TRANSIT: "in_transit",
    DELIVERED: "delivered",
    CANCELLED: "cancelled"
  } as Record<string, string>,
  inbound: {
    CREATED: "inbound.created",
    RECEIVED: "inbound.received",
    DISCREPANCY: "inbound.discrepancy"
  } as Record<string, string>
};

export const UoMConv = {
  // Normalize to kg / cm
  weight: { KG: 1, G: 0.001, LB: 0.45359237, MG: 1e-6 },
  length: { CM: 1, M: 100, MM: 0.1, IN: 2.54 }
};

export function toKg(value?: number, uom?: string) {
  if (value === undefined) return undefined;
  const f = UoMConv.weight[(uom || "KG").toUpperCase() as keyof typeof UoMConv.weight] || 1;
  return Number(value) * f;
}

export function toCm(value?: number, uom?: string) {
  if (value === undefined) return undefined;
  const f = UoMConv.length[(uom || "CM").toUpperCase() as keyof typeof UoMConv.length] || 1;
  return Number(value) * f;
}

// Warehouse code resolver placeholder
export function resolveWarehouseCode(obj: any): string | undefined {
  // Try multiple common paths seen in BYDM/receivingAdvice/shipment
  return obj?.receiver?.locationId || obj?.receiver?.name || obj?.warehouse?.code || obj?.shipTo?.locationId || obj?.locationId;
}

// Safe getters
export function deepGet(obj: any, path: string, def?: any): any {
  const parts = path.split(".");
  let cur = obj;
  for (const p of parts) {
    if (cur && typeof cur === "object" && p in cur) cur = cur[p];
    else return def;
  }
  return cur;
}

export function asArray<T=any>(x: any): T[] {
  if (Array.isArray(x)) return x as T[];
  if (x === null || x === undefined) return [];
  return [x as T];
}
