// mappers/bydm_shipment_mapper.ts
// Map BYDM Shipment → Canonical Shipment
import crypto from "node:crypto";
import { CanonicalShipment, StatusMap, deepGet, asArray, toKg, toCm } from "./common";

export function bydmShipmentToCanonicalShipment(sh: any): CanonicalShipment {
  const shipmentId = String(sh?.shipmentId ?? sh?.primaryId ?? "");
  const statusRaw = String(sh?.shipmentStatus ?? sh?.status ?? "PLANNED");
  const status = StatusMap.shipment[statusRaw] || statusRaw.toLowerCase();

  // Order reference (typical)
  const orderRef = deepGet(sh, "references.orderId") || deepGet(sh, "orderId") || undefined;

  // Tracking (if available)
  const tracking = {
    carrier: String(deepGet(sh, "carrier.name", "") || deepGet(sh, "transportation.carrier.name", "") || "" ) || undefined,
    code: String(deepGet(sh, "tracking.number", "") || deepGet(sh, "trackingId", "") || "" ) || undefined,
    url: String(deepGet(sh, "tracking.url", "") || "" ) || undefined
  };
  if (!tracking.carrier && !tracking.code && !tracking.url) delete (tracking as any).carrier;

  // Packages from logistic units
  const plannedLUs = asArray(deepGet(sh, "plannedLogisticUnit", []));
  const actualLUs = asArray(deepGet(sh, "actualLogisticUnit", []));
  const luAll = [...plannedLUs, ...actualLUs];

  const packages = luAll.map((lu: any) => {
    const pkgId = String(lu?.logisticUnitId || lu?.serialNumber || lu?.sscc || "");
    // Dimensions & weight
    const wVal = deepGet(lu, "weight.value"); const wU = deepGet(lu, "weight.uom");
    const lVal = deepGet(lu, "dimensions.length.value"); const lU = deepGet(lu, "dimensions.length.uom");
    const wVal2 = deepGet(lu, "dimensions.width.value"); const wU2 = deepGet(lu, "dimensions.width.uom");
    const hVal = deepGet(lu, "dimensions.height.value"); const hU = deepGet(lu, "dimensions.height.uom");

    const weightKg = toKg(Number(wVal), String(wU || "KG"));
    const dimensionsCm = {
      l: toCm(Number(lVal), String(lU || "CM")),
      w: toCm(Number(wVal2), String(wU2 || "CM")),
      h: toCm(Number(hVal), String(hU || "CM"))
    };
    return {
      packageId: pkgId || undefined,
      weightKg: Number.isFinite(weightKg as any) ? weightKg : undefined,
      dimensionsCm
    };
  }).filter((p: any) => p.packageId || p.weightKg || (p.dimensionsCm?.l || p.dimensionsCm?.w || p.dimensionsCm?.h));

  return {
    schemaVersion: "1.0",
    messageId: crypto.randomUUID(),
    eventType: "shipment.created",
    occurredAt: new Date().toISOString(),
    sourceSystem: "bydm",
    shipment: {
      shipmentId,
      orderId: orderRef,
      status,
      tracking: (tracking as any).carrier || (tracking as any).code || (tracking as any).url ? tracking : undefined,
      packages: packages.length ? packages : undefined
    },
    trace: {}
  };
}
