// mappers/bydm_mappers.ts
// BYDM → Canonical (POC)
import crypto from 'node:crypto';

export type CanonicalInventory = {
  schemaVersion: "1.0",
  messageId: string,
  eventType: "inventory.updated",
  occurredAt: string,
  sourceSystem?: string,
  inventory: Array<{
    sku: string,
    quantity: number | null,
    warehouse?: string,
    price?: { amount: number, currency: string }
  }>,
  trace?: Record<string, unknown>
};

export type CanonicalInbound = {
  schemaVersion: "1.0",
  messageId: string,
  eventType: "inbound.created" | "inbound.received" | "inbound.discrepancy",
  occurredAt: string,
  sourceSystem?: string,
  inbound: {
    shipmentId: string,
    reference?: string,
    warehouse?: { code?: string },
    logisticUnits: Array<{
      luId?: string,
      lineItems: Array<{ sku: string, qty: number, lot?: string, expiryDate?: string }>
    }>
  },
  trace?: Record<string, unknown>
};

export function bydmItemToCanonicalInventory(item: any): CanonicalInventory {
  const sku = item?.itemId?.primaryId ?? "";
  const locs = item?.specificLocations?.location ?? [];
  const entries = [] as CanonicalInventory["inventory"];

  for (const loc of locs) {
    const amount = Number(loc?.unitCost?.value);
    const currency = String(loc?.unitCost?.currencyCode || "MXN");
    entries.push({
      sku,
      quantity: null, // POC: si no tienes stock BYDM aquí, usa null/0
      warehouse: loc?.name || String(loc?.primaryId || ""),
      price: Number.isFinite(amount) ? { amount, currency } : undefined
    });
  }

  return {
    schemaVersion: "1.0",
    messageId: crypto.randomUUID(),
    eventType: "inventory.updated",
    occurredAt: new Date().toISOString(),
    sourceSystem: "bydm",
    inventory: entries.length ? entries : [{ sku, quantity: null }],
    trace: {}
  };
}

export function bydmItemToCanonicalInbound(item: any): CanonicalInbound {
  const sku = item?.itemId?.primaryId ?? "";
  const wh = item?.specificLocations?.location?.[0];
  const luInfos = item?.specificLocations?.location?.[0]?.itemLogisticUnitInformation
               || item?.itemLogisticUnitInformation
               || [];

  const lus: CanonicalInbound["inbound"]["logisticUnits"] = [];
  for (const cfg of luInfos) {
    for (const lu of (cfg?.itemLogisticUnit || [])) {
      const qty = Number(lu?.tradeItemQuantity?.value ?? 0) || 1;
      lus.push({
        luId: lu?.logisticUnitName || `LU-${sku}`,
        lineItems: [{ sku, qty }]
      });
    }
  }

  return {
    schemaVersion: "1.0",
    messageId: crypto.randomUUID(),
    eventType: "inbound.created",
    occurredAt: new Date().toISOString(),
    sourceSystem: "bydm",
    inbound: {
      shipmentId: `ASN-${Date.now()}`,
      reference: "RA",
      warehouse: { code: wh?.name || "MX-01" },
      logisticUnits: lus.length ? lus : [{ luId: `LU-${sku}`, lineItems: [{ sku, qty: 1 }] }]
    },
    trace: {}
  };
}
