// mappers/bydm_order_mapper.ts
// Map BYDM OrderRelease → Canonical Order
import crypto from "node:crypto";
import { CanonicalOrder, StatusMap, deepGet, asArray } from "./common";

export function bydmOrderReleaseToCanonicalOrder(orderRelease: any): CanonicalOrder {
  // Paths based on your BYDM 'orderRelease' sample
  const orderId = String(orderRelease?.orderId ?? orderRelease?.primaryId ?? "");
  const statusRaw = String(orderRelease?.orderStatus ?? orderRelease?.status ?? "OPEN");
  const status = StatusMap.order[statusRaw] || statusRaw.toLowerCase();

  const totalAmount = Number(deepGet(orderRelease, "totalMonetaryAmountIncludingTaxes.value", 0));
  const currency = String(deepGet(orderRelease, "totalMonetaryAmountIncludingTaxes.currencyCode", "MXN"));

  const buyerId = String(deepGet(orderRelease, "buyer.primaryId", ""));
  const buyerEmail = String(deepGet(orderRelease, "buyer.contact.0.communicationChannel.0.communicationValue", ""));

  // ShipTo address typical paths (adjust if your sample differs)
  const shipTo = deepGet(orderRelease, "orderLogisticalInformation.shipTo", {});
  const shipToAddr = shipTo?.address || {};
  const service = String(deepGet(orderRelease, "orderServiceLevel.serviceLevelCode", "") || deepGet(orderRelease, "orderTypeCode", ""));

  // Lines
  const lines = asArray(deepGet(orderRelease, "lineItem", []));
  const items = lines.map((li: any) => {
    const sku = String(deepGet(li, "transactionalTradeItem.primaryId", ""));
    const qty = Number(deepGet(li, "requestedQuantity.value", 0) || deepGet(li, "orderedQuantity.value", 0) || 0);
    const price = Number(deepGet(li, "netPrice.value", undefined));
    return { sku, qty, price: Number.isFinite(price) ? price : undefined };
  }).filter((x: any) => x.sku);

  return {
    schemaVersion: "1.0",
    messageId: crypto.randomUUID(),
    eventType: "order.created",
    occurredAt: new Date().toISOString(),
    sourceSystem: "bydm",
    order: {
      orderId,
      status,
      currency,
      totalAmount,
      buyer: { id: buyerId || undefined, email: buyerEmail || undefined },
      shipping: {
        service: service || undefined,
        address: {
          name: shipTo?.name || shipToAddr?.name,
          line1: shipToAddr?.streetAddressOne,
          city: shipToAddr?.city,
          state: shipToAddr?.state,
          postalCode: shipToAddr?.postalCode,
          country: shipToAddr?.countryCode
        }
      },
      items,
      marketplace: { channel: "bydm", site: "internal" }
    },
    trace: {}
  };
}
