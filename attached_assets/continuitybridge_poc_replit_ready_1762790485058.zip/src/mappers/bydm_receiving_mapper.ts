// mappers/bydm_receiving_mapper.ts
// Map BYDM receivingAdvice → Canonical Inbound
import crypto from "node:crypto";
import { CanonicalInbound, StatusMap, deepGet, asArray, resolveWarehouseCode } from "./common";

export function bydmReceivingAdviceToCanonicalInbound(ra: any): CanonicalInbound {
  // Header
  const shipmentId = String(ra?.shipmentId || ra?.primaryId || ra?.receivingId || `ASN-${Date.now()}`);
  const ref = String(deepGet(ra, "references.purchaseOrderId", "") || deepGet(ra, "purchaseOrderId", "") || "RA");
  const warehouseCode = resolveWarehouseCode(ra);

  // Logistic Units (tree)
  // Usually ra.logisticUnit[] with nested content; also lines may exist under 'lineItem'
  const lus = [] as CanonicalInbound["inbound"]["logisticUnits"];
  const raLUs = asArray(deepGet(ra, "logisticUnit", []));
  const raLines = asArray(deepGet(ra, "lineItem", []));

  // Helper to decide qty preference: accepted > received > despatched > expected
  function pickQty(x: any): number {
    const accepted = Number(deepGet(x, "quantityAccepted.value", NaN));
    const received = Number(deepGet(x, "quantityReceived.value", NaN));
    const despatched = Number(deepGet(x, "quantityDespatched.value", NaN));
    const expected = Number(deepGet(x, "expectedQuantity.value", NaN));
    const arr = [accepted, received, despatched, expected].filter(v => Number.isFinite(v));
    return (arr.length ? arr[0] : 0) || 0;
  }

  // Case A: derive from LUs if present
  for (const lu of raLUs) {
    const luId = String(lu?.logisticUnitId || lu?.sscc || lu?.serialNumber || "");
    const liArr = asArray(deepGet(lu, "lineItem", []));
    const lineItems = liArr.map((li: any) => {
      const sku = String(deepGet(li, "tradeItem.primaryId", "") || deepGet(li, "sku", ""));
      const qty = pickQty(li);
      const lot = deepGet(li, "batch.lot", undefined) || deepGet(li, "lot", undefined);
      const expiryDate = deepGet(li, "batch.expiryDate", undefined) || deepGet(li, "expiryDate", undefined);
      return { sku, qty, lot, expiryDate };
    }).filter((x: any) => x.sku);
    if (lineItems.length) {
      lus.push({ luId: luId || undefined, lineItems });
    }
  }

  // Case B: if no LU structure, flatten from top-level lineItem
  if (!lus.length && raLines.length) {
    const lineItems = raLines.map((li: any) => {
      const sku = String(deepGet(li, "tradeItem.primaryId", "") || deepGet(li, "sku", ""));
      const qty = pickQty(li);
      const lot = deepGet(li, "batch.lot", undefined) || deepGet(li, "lot", undefined);
      const expiryDate = deepGet(li, "batch.expiryDate", undefined) || deepGet(li, "expiryDate", undefined);
      return { sku, qty, lot, expiryDate };
    }).filter((x: any) => x.sku);
    if (lineItems.length) {
      lus.push({ luId: undefined, lineItems });
    }
  }

  // Fallback: ensure at least one line item exists for demo purposes
  if (!lus.length) {
    lus.push({ luId: undefined, lineItems: [] });
  }

  return {
    schemaVersion: "1.0",
    messageId: crypto.randomUUID(),
    eventType: "inbound.received",
    occurredAt: new Date().toISOString(),
    sourceSystem: "bydm",
    inbound: {
      shipmentId,
      reference: ref,
      warehouse: { code: warehouseCode },
      logisticUnits: lus
    },
    trace: {}
  };
}
