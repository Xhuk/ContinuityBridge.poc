
import fs from "node:fs";
import path from "node:path";
import { runMapping } from "./engine/mappingEngine.js";

const inputs = [
  ["examples/orderRelease.sample.json", "mappings/bydm→canonical/order_release_to_canonical_order.yaml", "schemas/canonical/order.schema.json"],
  ["examples/shipment.sample.json", "mappings/bydm→canonical/shipment_to_canonical_shipment.yaml", "schemas/canonical/shipment.schema.json"],
  ["examples/receivingAdvice.sample.json", "mappings/bydm→canonical/receiving_advice_to_canonical_inbound.yaml", "schemas/canonical/inbound.schema.json"],
  ["examples/inventoryReport.sample.json", "mappings/bydm→canonical/inventory_report_to_canonical_inventory.yaml", "schemas/canonical/inventory.schema.json"]
];

for (const [inp, map, sch] of inputs) {
  console.log("\n--- DEMO", map, "---");
  const input = JSON.parse(fs.readFileSync(path.resolve(inp), "utf8"));
  const out = runMapping(path.resolve(map), input);
  console.log(JSON.stringify(out, null, 2));
}
