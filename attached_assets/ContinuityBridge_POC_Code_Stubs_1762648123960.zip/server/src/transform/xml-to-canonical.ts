import { XMLParser } from "fast-xml-parser";
export async function toCanonical(xml: string){
  const parser = new XMLParser({ ignoreAttributes:false, parseTagValue:true, trimValues:true });
  const json = parser.parse(xml);
  // TODO: usar mapping.yml para transformar
  return { sku: json?.PART_INB_IFD?.CTRL_SEG?.PART_SEG?.PRTNUM };
}
