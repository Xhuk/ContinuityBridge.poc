export interface QueueProvider{ enqueue(t:string,p:string):Promise<void>; consume(t:string,h:(p:string)=>Promise<void>,o?:{concurrency?:number}):Promise<void>; }
