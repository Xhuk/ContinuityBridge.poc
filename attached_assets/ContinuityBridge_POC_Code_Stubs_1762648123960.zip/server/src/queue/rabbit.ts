export class RabbitQueue{ /* stub */ }
