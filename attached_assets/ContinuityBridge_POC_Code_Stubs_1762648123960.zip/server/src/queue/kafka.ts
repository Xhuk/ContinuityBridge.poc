export class KafkaQueue{ /* stub */ }
