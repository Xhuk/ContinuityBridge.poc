import { QueueProvider } from "./QueueProvider.js";
export class InMemoryQueue implements QueueProvider{
  private queues = new Map<string,string[]>();
  async enqueue(t:string,p:string){ const q=this.queues.get(t)||[]; q.push(p); this.queues.set(t,q); }
  async consume(t:string,h:(p:string)=>Promise<void>){ setInterval(async()=>{ const q=this.queues.get(t)||[]; const m=q.shift(); if(m){ await h(m); this.queues.set(t,q);} }, 50); }
}
