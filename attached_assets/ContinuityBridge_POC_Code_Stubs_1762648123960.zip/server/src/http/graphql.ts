export async function mountGraphQL(){ /* stub */ }
