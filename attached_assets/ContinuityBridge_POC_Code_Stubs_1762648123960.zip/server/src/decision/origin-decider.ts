export function decideOrigin(){ return { originWarehouseId:'WH1', reason:'default' }; }
