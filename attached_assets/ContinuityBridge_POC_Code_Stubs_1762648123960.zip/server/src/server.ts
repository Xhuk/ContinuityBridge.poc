import express from "express";
import rest from "./http/rest.js";
const app = express();
app.use(express.json());
app.use(rest);
const port = Number(process.env.PORT || 5050);
app.listen(port, ()=> console.log(`API on http://localhost:${port}`));
