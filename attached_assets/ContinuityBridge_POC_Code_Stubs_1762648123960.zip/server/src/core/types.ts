export type CanonicalItem = { sku: string };
