export async function sendToAmazon(){ return { ok:true } }
