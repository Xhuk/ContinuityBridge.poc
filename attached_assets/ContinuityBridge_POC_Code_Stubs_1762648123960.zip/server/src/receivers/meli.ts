export async function sendToMeli(){ return { ok:true } }
