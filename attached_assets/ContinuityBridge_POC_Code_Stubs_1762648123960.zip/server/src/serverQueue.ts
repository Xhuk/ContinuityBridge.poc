export const queue = { enqueue: async()=>{}, consume: async()=>{} } as any;
