import Database from "better-sqlite3";
import path from "node:path";
import fs from "node:fs";

const dataDir = path.resolve("data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "monitor.db"));

db.exec(`
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  ts INTEGER NOT NULL,
  direction TEXT NOT NULL CHECK (direction in ('inbound','outbound')),
  entity TEXT NOT NULL,
  channel TEXT,
  status TEXT,
  payload_json TEXT NOT NULL,
  meta_json TEXT,
  corr_id TEXT,
  latency_ms INTEGER
);
CREATE INDEX IF NOT EXISTS idx_messages_ts ON messages(ts);
CREATE INDEX IF NOT EXISTS idx_messages_dir ON messages(direction);
CREATE INDEX IF NOT EXISTS idx_messages_entity ON messages(entity);
CREATE INDEX IF NOT EXISTS idx_messages_corr ON messages(corr_id);

CREATE TABLE IF NOT EXISTS workers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  host TEXT,
  queue TEXT,
  binding_key TEXT,
  prefetch INTEGER,
  last_seen_ts INTEGER NOT NULL,
  status TEXT,
  processed_ok INTEGER DEFAULT 0,
  processed_fail INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_workers_last_seen ON workers(last_seen_ts);
`);

function rnd() { return Math.random().toString(36).slice(2); }
export function cryptoRandomId() { return rnd() + rnd() + Date.now().toString(36); }

export type MessageRow = {
  id: string;
  ts: number;
  direction: "inbound" | "outbound";
  entity: string;
  channel?: string | null;
  status?: string | null;
  payload_json: string;
  meta_json?: string | null;
  corr_id?: string | null;
  latency_ms?: number | null;
};

export function saveMessage(row: Omit<MessageRow, "id">) {
  const id = cryptoRandomId();
  const stmt = db.prepare(`INSERT INTO messages (id, ts, direction, entity, channel, status, payload_json, meta_json, corr_id, latency_ms)
    VALUES (@id, @ts, @direction, @entity, @channel, @status, @payload_json, @meta_json, @corr_id, @latency_ms)`);
  stmt.run({ id, ...row });
  return id;
}

export function listMessages(whereSql: string, params: any, limit=50, offset=0) {
  const total = db.prepare(`SELECT COUNT(*) as c FROM messages ${whereSql}`).get(params).c;
  const rows = db.prepare(`SELECT * FROM messages ${whereSql} ORDER BY ts DESC LIMIT @limit OFFSET @offset`)
                .all({ ...params, limit, offset });
  return { total, rows };
}

export type WorkerRow = {
  id: string;
  name: string;
  host?: string | null;
  queue?: string | null;
  binding_key?: string | null;
  prefetch?: number | null;
  last_seen_ts: number;
  status?: string | null;
  processed_ok?: number | null;
  processed_fail?: number | null;
};

export function upsertWorker(w: Omit<WorkerRow, "id"> & { id?: string }) {
  const id = w.id ?? cryptoRandomId();
  db.prepare(`INSERT INTO workers (id, name, host, queue, binding_key, prefetch, last_seen_ts, status, processed_ok, processed_fail)
             VALUES (@id, @name, @host, @queue, @binding_key, @prefetch, @last_seen_ts, @status, @processed_ok, @processed_fail)
             ON CONFLICT(id) DO UPDATE SET
               name=excluded.name,
               host=excluded.host,
               queue=excluded.queue,
               binding_key=excluded.binding_key,
               prefetch=excluded.prefetch,
               last_seen_ts=excluded.last_seen_ts,
               status=excluded.status`).run({ id, ...w });
  return id;
}
export function updateWorkerCounters(id: string, okDelta: number, failDelta: number) {
  db.prepare(`UPDATE workers SET processed_ok = processed_ok + @okDelta, processed_fail = processed_fail + @failDelta WHERE id=@id`)
    .run({ id, okDelta, failDelta });
}
export function listWorkers() {
  return db.prepare(`SELECT * FROM workers ORDER BY last_seen_ts DESC`).all();
}

export default db;
