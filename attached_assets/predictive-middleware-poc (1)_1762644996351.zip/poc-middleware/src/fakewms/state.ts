let delayMs = 100;
let failRate = 0; // 0..1
const recent:any[] = [];

export function setConfig(d:number, f:number){
  delayMs = Math.max(0, d|0);
  failRate = Math.min(1, Math.max(0, f));
}
export function getConfig(){ return { delayMs, failRate, recent: recent.slice(-50).reverse() }; }

export async function handlePush(body:any){
  await new Promise(r => setTimeout(r, delayMs));
  const fail = Math.random() < failRate;
  recent.push({ ts: Date.now(), ok: !fail, body });
  if (fail) { const err:any = new Error("fake-wms simulated failure"); err.status=500; throw err; }
  return { ok: true };
}
