import path from "node:path";
import fs from "node:fs";
import * as XLSX from "xlsx";

/** Columns (POC):
 * source_xpath, target_path, required_json (0/1), required_xml (0/1)
 */
export type MapRule = { source_xpath: string; target_path: string; required_json?: number; required_xml?: number; };
let rules: MapRule[] = [];
let lastLoadError: string | null = null;

export function loadXlsxMapping(filePath?: string) {
  try {
    const p = filePath || path.resolve("mapping","Item.xlsx");
    if (!fs.existsSync(p)) { lastLoadError = `Mapping XLSX not found at ${p}`; rules = []; return; }
    const wb = XLSX.readFile(p);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows: any[] = XLSX.utils.sheet_to_json(ws, { defval: "" });
    rules = rows.map(r => ({
      source_xpath: String(r.source_xpath || r.Source || r.source || "").trim(),
      target_path: String(r.target_path || r.Target || r.target || "").trim(),
      required_json: Number(r.required_json || r.json_required || r["cardinality json"] || 0),
      required_xml: Number(r.required_xml || r.xml_required || r["cardinality xml"] || 0),
    })).filter(r => r.source_xpath && r.target_path);
    lastLoadError = null;
  } catch (e:any) { lastLoadError = String(e); rules = []; }
}
export function getMappingStatus(){ return { count: rules.length, error: lastLoadError }; }

function getByPath(obj:any, ps:string){
  return ps.split(".").reduce((a:any,k)=> (a && typeof a==="object") ? a[k] : undefined, obj);
}
function setByPath(obj:any, ps:string, v:any){
  const parts = ps.split("."); let cur = obj;
  for(let i=0;i<parts.length-1;i++){ const k=parts[i]; if(!cur[k]||typeof cur[k]!=="object") cur[k]={}; cur=cur[k]; }
  cur[parts[parts.length-1]] = v;
}

export function mapIFDToBYDMUsingRules(xmlObj:any){
  const out:any = {};
  for(const r of rules){
    const v = getByPath(xmlObj, r.source_xpath);
    if(v !== undefined && v !== null && v !== "") setByPath(out, r.target_path, v);
    else if (r.required_json === 1) setByPath(out, r.target_path, null);
  }
  return out;
}
