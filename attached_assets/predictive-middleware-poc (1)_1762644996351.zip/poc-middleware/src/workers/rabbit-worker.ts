import amqplib from "amqplib";
import os from "node:os";
import { pushWmsHttp } from "../targets/wms.js";
import db, { saveMessage, upsertWorker, updateWorkerCounters } from "../db/index.js";

function amqpUrlFromEnv() {
  const host = process.env.RABBIT_HOST || "localhost";
  const port = process.env.RABBIT_PORT || "5672";
  const user = process.env.RABBIT_USER || "guest";
  const pass = process.env.RABBIT_PASS || "guest";
  const vhost = encodeURIComponent(process.env.RABBIT_VHOST || "/");
  return `amqp://${user}:${pass}@${host}:${port}/${vhost}`;
}

(async () => {
  const url = amqpUrlFromEnv();
  const conn = await amqplib.connect(url);
  const ch = await conn.createChannel();

  const exchange = process.env.RABBIT_EXCHANGE || "bydm.exchange";
  const base = process.env.RABBIT_ROUTING_BASE || "items";
  const queue = process.env.RABBIT_QUEUE || `bydm.items.sap.q`;
  const bind = process.env.RABBIT_BINDING_KEY || `items.sap.*`;
  const prefetch = parseInt(process.env.RABBIT_PREFETCH || "20", 10);

  await ch.assertExchange(exchange, process.env.RABBIT_EXCHANGE_TYPE || "topic", { durable: true });
  await ch.assertQueue(queue, { durable: true });
  await ch.bindQueue(queue, exchange, bind);
  ch.prefetch(prefetch);

  const host = os.hostname?.() || "host";
  const name = `${host}-${process.pid}`;
  const workerId = upsertWorker({ name, host, queue, binding_key: bind, prefetch, last_seen_ts: Date.now(), status: "running", processed_ok: 0, processed_fail: 0 });

  setInterval(() => {
    upsertWorker({ id: workerId, name, host, queue, binding_key: bind, prefetch, last_seen_ts: Date.now(), status: "running", processed_ok: 0, processed_fail: 0 });
  }, 15000);

  console.log(`[worker] queue='${queue}' bind='${bind}' prefetch=${prefetch}`);

  ch.consume(queue, async (msg) => {
    if (!msg) return;
    try {
      const rk = msg.fields.routingKey;
      const body = JSON.parse(msg.content.toString());
      if (process.env.WMS_HTTP_URL && process.env.WMS_HTTP_URL.length > 0) {
        await pushWmsHttp(body);
      }
      const deliveredTs = Date.now();
      const enqTs = Number(body.enqueued_ts || deliveredTs);
      const procLatency = Math.max(0, deliveredTs - enqTs);
      saveMessage({ ts: deliveredTs, direction: "outbound", entity: body.entity || "item", channel: rk, status: "delivered", payload_json: JSON.stringify(body.payload || body), meta_json: JSON.stringify({ worker: true }), corr_id: body.corr_id, latency_ms: procLatency });
      updateWorkerCounters(workerId, 1, 0);
      ch.ack(msg);
    } catch (e:any) {
      console.error("[worker] error:", e);
      try {
        const body = JSON.parse(msg.content.toString());
        const dest = body.dest || "sap";
        const attempts = Number(body.attempts || 0) + 1;
        const payload = Buffer.from(JSON.stringify({ ...body, attempts }));
        const ex = process.env.RABBIT_EXCHANGE || "bydm.exchange";
        if (attempts === 1) ch.publish(ex, `${base}.${dest}.retry.1m`, payload, { persistent: true, contentType: "application/json" });
        else if (attempts === 2) ch.publish(ex, `${base}.${dest}.retry.5m`, payload, { persistent: true, contentType: "application/json" });
        else ch.publish(ex, `${base}.${dest}.dlq`, msg.content, { persistent: true, contentType: "application/json" });
      } catch {}
      ch.nack(msg, false, false);
      const failedTs = Date.now();
      try {
        const body = JSON.parse(msg.content.toString());
        saveMessage({ ts: failedTs, direction: "outbound", entity: body.entity || "item", channel: "worker", status: "failed", payload_json: msg.content.toString(), meta_json: JSON.stringify({ worker: true, error: String(e) }), corr_id: body.corr_id });
        updateWorkerCounters(workerId, 0, 1);
      } catch {}
    }
  }, { noAck: false });
})();
