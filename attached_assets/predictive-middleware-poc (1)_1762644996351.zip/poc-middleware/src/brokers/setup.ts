import amqplib from "amqplib";

function amqpUrlFromEnv() {
  const host = process.env.RABBIT_HOST || "localhost";
  const port = process.env.RABBIT_PORT || "5672";
  const user = process.env.RABBIT_USER || "guest";
  const pass = process.env.RABBIT_PASS || "guest";
  const vhost = encodeURIComponent(process.env.RABBIT_VHOST || "/");
  return `amqp://${user}:${pass}@${host}:${port}/${vhost}`;
}

export async function ensureQueuesForDest(dest: string) {
  const url = amqpUrlFromEnv();
  const conn = await amqplib.connect(url);
  const ch = await conn.createChannel();
  const ex = process.env.RABBIT_EXCHANGE || "bydm.exchange";
  const type = process.env.RABBIT_EXCHANGE_TYPE || "topic";
  await ch.assertExchange(ex, type as any, { durable: true });

  const mainQ = `bydm.items.${dest}.q`;
  const retry1 = `bydm.items.${dest}.retry.1m.q`;
  const retry5 = `bydm.items.${dest}.retry.5m.q`;
  const dlq = `bydm.items.${dest}.dlq.q`;

  await ch.assertQueue(mainQ, { durable: true });
  await ch.bindQueue(mainQ, ex, `items.${dest}.*`);

  await ch.assertQueue(retry1, {
    durable: true,
    arguments: {
      "x-message-ttl": 60000,
      "x-dead-letter-exchange": ex,
      "x-dead-letter-routing-key": `items.${dest}.upsert`
    }
  });
  await ch.bindQueue(retry1, ex, `items.${dest}.retry.1m`);

  await ch.assertQueue(retry5, {
    durable: true,
    arguments: {
      "x-message-ttl": 300000,
      "x-dead-letter-exchange": ex,
      "x-dead-letter-routing-key": `items.${dest}.upsert`
    }
  });
  await ch.bindQueue(retry5, ex, `items.${dest}.retry.5m`);

  await ch.assertQueue(dlq, { durable: true });
  await ch.bindQueue(dlq, ex, `items.${dest}.dlq`);

  await ch.close();
  await conn.close();
}

export async function ensureAllQueues() {
  await ensureQueuesForDest("sap");
  await ensureQueuesForDest("3pl");
}
