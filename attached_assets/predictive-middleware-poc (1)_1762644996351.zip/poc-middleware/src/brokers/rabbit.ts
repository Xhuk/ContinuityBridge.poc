import amqplib from "amqplib";

function amqpUrlFromEnv() {
  const host = process.env.RABBIT_HOST || "localhost";
  const port = process.env.RABBIT_PORT || "5672";
  const user = process.env.RABBIT_USER || "guest";
  const pass = process.env.RABBIT_PASS || "guest";
  const vhost = encodeURIComponent(process.env.RABBIT_VHOST || "/");
  return `amqp://${user}:${pass}@${host}:${port}/${vhost}`;
}

let _conn: amqplib.Connection | null = null;
let _ch: amqplib.Channel | null = null;

export async function getChannel() {
  if (_ch) return _ch;
  const url = amqpUrlFromEnv();
  _conn = await amqplib.connect(url);
  _ch = await _conn.createChannel();
  const exchange = process.env.RABBIT_EXCHANGE || "bydm.exchange";
  const type = process.env.RABBIT_EXCHANGE_TYPE || "topic";
  await _ch.assertExchange(exchange, type as any, { durable: true });
  return _ch;
}

export async function publishRabbit(payload: any, rkOverride?: string) {
  const ch = await getChannel();
  const exchange = process.env.RABBIT_EXCHANGE || "bydm.exchange";
  const rk = rkOverride || "items.upsert";
  const msg = Buffer.from(JSON.stringify(payload));
  ch.publish(exchange, rk, msg, { persistent: true, contentType: "application/json" });
  return rk;
}
