import { Router } from "express";
import { PM } from "../pm/worker-manager.js";

const router = Router();
router.get("/state", (_req, res) => res.json({ ok: true, state: PM.getState() }));
router.post("/autorestart", (req, res) => { PM.setAutoRestart(!!req.body?.enabled); res.json({ ok: true, autorestart: PM.getState().autorestart }); });
router.post("/defaults", (req, res) => { const { prefetch, count, wmsUrl, auth } = req.body ?? {}; PM.setDefaults({ prefetch, count, wmsUrl, auth }); res.json({ ok: true, defaults: PM.getState().defaults }); });
router.post("/scale", async (req, res) => {
  const dest = String(req.body?.dest || "sap");
  const count = Math.max(0, parseInt(String(req.body?.count ?? PM.getState().defaults.count)));
  const prefetch = req.body?.prefetch ? parseInt(String(req.body.prefetch)) : undefined;
  const wmsUrl = req.body?.wmsUrl; const auth = req.body?.auth; const queue = req.body?.queue; const bindingKey = req.body?.bindingKey;
  try { const list = await PM.scale(dest, count, { prefetch, wmsUrl, auth, queue, bindingKey }); res.json({ ok: true, dest, count: list.length, pids: list.map(p=>p.pid) }); }
  catch (e) { res.status(500).json({ ok: false, error: String(e) }); }
});
router.post("/stop", (req, res) => { const dest = String(req.body?.dest || "sap"); PM.stop(dest); res.json({ ok: true, dest }); });
export default router;
