import { Router } from "express";
import db, { listMessages } from "../db/index.js";

const router = Router();
router.get("/", (_req, res) => res.sendFile(process.cwd() + "/public/monitor.html"));

router.get("/api/messages", (req, res) => {
  const q = req.query as any; const where: string[] = []; const params: any = {};
  if (q.direction) { where.push("direction = @direction"); params.direction = q.direction; }
  if (q.entity) { where.push("entity = @entity"); params.entity = q.entity; }
  if (q.start) { where.push("ts >= @start"); params.start = parseInt(q.start); }
  if (q.end) { where.push("ts <= @end"); params.end = parseInt(q.end); }
  const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
  const limit = q.limit ? parseInt(q.limit) : 50; const offset = q.offset ? parseInt(q.offset) : 0;
  const { total, rows } = listMessages(whereSql, params, limit, offset);
  res.json({ ok: true, total, rows });
});

router.get("/api/messages/export.ndjson", (_req, res) => {
  res.setHeader("content-type","application/x-ndjson");
  const rows = db.prepare("SELECT * FROM messages ORDER BY ts DESC LIMIT 1000").all();
  for (const r of rows) res.write(JSON.stringify(r) + "\n");
  res.end();
});
router.get("/api/messages/export.csv", (_req, res) => {
  res.setHeader("content-type","text/csv");
  const rows = db.prepare("SELECT * FROM messages ORDER BY ts DESC LIMIT 1000").all();
  const header = Object.keys(rows[0]||{id:1}).join(",") + "\n";
  res.write(header);
  for (const r of rows) res.write(Object.values(r).map(v=>JSON.stringify(v??"")).join(",") + "\n");
  res.end();
});

router.get("/api/kpi/summary", (req, res) => {
  const { direction, entity, start, end } = req.query as Record<string, string>;
  const where: string[] = []; const params: any = {};
  if (direction) { where.push("direction = @direction"); params.direction = direction; }
  if (entity) { where.push("entity = @entity"); params.entity = entity; }
  if (start) { where.push("ts >= @start"); params.start = parseInt(start); }
  if (end) { where.push("ts <= @end"); params.end = parseInt(end); }
  const whereSql = where.length ? "WHERE " + where.join(" AND ") : "";
  const total = db.prepare(`SELECT COUNT(*) as c FROM messages ${whereSql}`).get(params).c;
  const inbound = db.prepare(`SELECT COUNT(*) as c FROM messages ${whereSql} ${whereSql ? " AND" : "WHERE"} direction='inbound'`).get(params).c;
  const outbound = db.prepare(`SELECT COUNT(*) as c FROM messages ${whereSql} ${whereSql ? " AND" : "WHERE"} direction='outbound'`).get(params).c;
  const now = Date.now();
  const last24 = db.prepare(`SELECT COUNT(*) as c FROM messages ${whereSql} ${whereSql ? " AND" : "WHERE"} ts >= @t24`).get({ ...params, t24: now-24*3600*1000 }).c;
  res.json({ ok: true, total, inbound, outbound, last24 });
});

router.get("/api/kpi/series", (req, res) => {
  const { direction, entity, start, end, group } = req.query as Record<string, string>;
  const g = (group === "day") ? "day" : "hour";
  const s = start ? parseInt(start) : Date.now()-24*3600*1000;
  const e = end ? parseInt(end) : Date.now();
  const bucketMs = (g === "day") ? 24*3600*1000 : 3600*1000;

  const where: string[] = ["ts >= @s AND ts <= @e"]; const params: any = { s, e };
  if (direction) { where.push("direction = @direction"); params.direction = direction; }
  if (entity) { where.push("entity = @entity"); params.entity = entity; }
  const rows = db.prepare(`SELECT ts FROM messages WHERE ${where.join(" AND ")} ORDER BY ts ASC`).all(params);

  const buckets: Record<string, number> = {};
  let t = s - (s % bucketMs);
  while (t <= e) { buckets[String(t)] = 0; t += bucketMs; }
  for (const r of rows) { const b = r.ts - (r.ts % bucketMs); const key = String(b); buckets[key] = (buckets[key]||0) + 1; }
  const series = Object.keys(buckets).sort((a,b)=>Number(a)-Number(b)).map(k => ({ ts: Number(k), count: buckets[k] }));
  res.json({ ok: true, group: g, start: s, end: e, bucketMs, series });
});

router.get("/api/kpi/latency", (req, res) => {
  const { entity, start, end } = req.query as Record<string, string>;
  const where: string[] = ["direction = 'outbound'", "latency_ms IS NOT NULL"]; const params: any = {};
  if (entity) { where.push("entity = @entity"); params.entity = entity; }
  if (start) { where.push("ts >= @start"); params.start = parseInt(start); }
  if (end) { where.push("ts <= @end"); params.end = parseInt(end); }
  const rows = db.prepare(`SELECT latency_ms FROM messages WHERE ${where.join(" AND ")} ORDER BY latency_ms ASC`).all(params).map((r:any)=>r.latency_ms);
  if (rows.length === 0) return res.json({ ok: true, count: 0, avg: 0, p50: 0, p95: 0, p99: 0 });
  const sum = rows.reduce((a:number,b:number)=>a+b, 0); const avg = sum/rows.length;
  const p = (q:number)=> rows[Math.min(rows.length-1, Math.floor(q*(rows.length-1)))];
  res.json({ ok: true, count: rows.length, avg, p50: p(0.5), p95: p(0.95), p99: p(0.99) });
});

router.get("/api/workers", (_req, res) => {
  const rows = db.prepare("SELECT * FROM workers ORDER BY last_seen_ts DESC").all();
  res.json({ ok: true, rows });
});

export default router;
