import { Router } from "express";
import { getConfig, setConfig, handlePush } from "../fakewms/state.js";
import { saveMessage } from "../db/index.js";

const router = Router();

router.get("/config", (_req, res) => res.json({ ok: true, ...getConfig() }));
router.post("/config", (req, res) => {
  const d = Number(req.body?.delayMs ?? 100);
  const f = Number(req.body?.failRate ?? 0);
  setConfig(d, f);
  res.json({ ok: true, ...getConfig() });
});

router.post("/", async (req, res) => {
  try {
    const out = await handlePush(req.body);
    saveMessage({ ts: Date.now(), direction: "outbound", entity: "fake-wms", channel: "http", status: "received", payload_json: JSON.stringify(req.body), meta_json: JSON.stringify({ fake: true }) });
    res.json(out);
  } catch (e:any) {
    res.status(e.status || 500).json({ ok:false, error:String(e) });
  }
});

export default router;
