import { Router } from "express";
import { saveMessage } from "../db/index.js";
import { publishRabbit } from "../brokers/rabbit.js";
import { validateXml, parseXml } from "../utils/xml.js";
import { loadXlsxMapping, getMappingStatus, mapIFDToBYDMUsingRules } from "../mapping/xlsx-mapper.js";
import { ensureAllQueues } from "../brokers/setup.js";

loadXlsxMapping();
ensureAllQueues().catch(()=>{});

function basicFallback(xmlObj:any){
  const part = xmlObj?.PART_INB_IFD?.CTRL_SEG?.PART_SEG || {};
  return {
    item: {
      number: part.PRTNUM ?? null,
      uom: part.STKUOM ?? null,
      status: part.RCVSTS ?? null,
      shortDesc: part.PART_DESCRIPTION_SEG?.SHORT_DSC ?? null
    }
  };
}

const router = Router();
router.get("/mapping/status", (_req, res) => res.json({ ok: true, status: getMappingStatus() }));

router.post("/ifd", async (req, res) => {
  try {
    const xml: string | undefined = req.body?.xml;
    const dest = (req.query.dest as string) || (req.body?.dest as string) || "sap";
    if (!xml) return res.status(400).json({ ok:false, error:"Body must include { xml: string }" });

    const startTs = Date.now();
    validateXml(xml);
    const xmlObj = parseXml(xml);
    let bydm = mapIFDToBYDMUsingRules(xmlObj);
    if (!bydm || Object.keys(bydm).length === 0) bydm = basicFallback(xmlObj);

    const endTs = Date.now();
    const corrId = Math.random().toString(36).slice(2) + Date.now().toString(36);

    saveMessage({ ts: startTs, direction: "inbound", entity: "item", channel: "http", status: "parsed", payload_json: JSON.stringify({ xml }), meta_json: JSON.stringify({ route: "/items/ifd", mapping: getMappingStatus() }), corr_id: corrId });
    const rk = `items.${dest}.upsert`;

    await publishRabbit({ corr_id: corrId, entity: "item", dest, enqueued_ts: Date.now(), payload: bydm }, rk);
    saveMessage({ ts: endTs, direction: "outbound", entity: "item", channel: rk, status: "queued", payload_json: JSON.stringify(bydm), meta_json: JSON.stringify({ route: "/items/ifd" }), corr_id: corrId, latency_ms: Math.max(0, endTs - startTs) });

    res.json({ ok: true, bydm, corr_id: corrId, topic: rk, mapping: getMappingStatus() });
  } catch (e:any) {
    res.status(500).json({ ok:false, error: String(e) });
  }
});

export default router;
