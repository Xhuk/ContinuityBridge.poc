import { spawn } from "node:child_process";
import path from "node:path";

type GroupKey = string;
export type WorkerProc = { pid: number; started_ts: number; dest: GroupKey; env: Record<string, string>; };
export type PMState = { autorestart: boolean; groups: Record<GroupKey, WorkerProc[]>; defaults: { prefetch: number; count: number; wmsUrl: string; auth: string; }; };

class WorkerManager {
  private state: PMState = { autorestart: true, groups: {}, defaults: { prefetch: 20, count: 2, wmsUrl: "http://localhost:8080/fake-wms", auth: "" } };
  getState() { return this.state; }
  setAutoRestart(v: boolean) { this.state.autorestart = v; }
  setDefaults(d: Partial<PMState["defaults"]>) { this.state.defaults = { ...this.state.defaults, ...d }; }
  list(dest?: GroupKey) { return dest ? (this.state.groups[dest] ?? []) : this.state.groups; }
  async scale(dest: GroupKey, count: number, opts?: Partial<{prefetch:number; wmsUrl:string; auth:string; bindingKey:string; queue:string;}>) {
    const current = this.state.groups[dest] ?? [];
    if (count > current.length) {
      for (let i = 0; i < count - current.length; i++) this.spawnOne(dest, opts);
    } else if (count < current.length) {
      for (let i = 0; i < current.length - count; i++) { const p = this.state.groups[dest]?.pop(); if (p) try { process.kill(p.pid); } catch {} }
    }
    return this.list(dest);
  }
  stop(dest: GroupKey) { const arr = this.state.groups[dest] ?? []; for (const p of arr) { try { process.kill(p.pid); } catch {} } this.state.groups[dest] = []; }
  spawnOne(dest: GroupKey, opts?: Partial<{prefetch:number; wmsUrl:string; auth:string; bindingKey:string; queue:string;}>) {
    const prefetch = String(opts?.prefetch ?? this.state.defaults.prefetch);
    const wmsUrl = String(opts?.wmsUrl ?? this.state.defaults.wmsUrl);
    const auth = String(opts?.auth ?? this.state.defaults.auth);
    const queue = opts?.queue ?? `bydm.items.${dest}.q`;
    const bindingKey = opts?.bindingKey ?? `items.${dest}.*`;
    const env = { ...process.env, ENABLE_RABBIT: "true", RABBIT_QUEUE: queue, RABBIT_BINDING_KEY: bindingKey, RABBIT_PREFETCH: prefetch, ENABLE_WMS_PUSH: "true", WMS_PUSH_MODE: "http", WMS_HTTP_URL: wmsUrl, WMS_HTTP_AUTH: auth };
    const cmd = "node"; const args = ["--loader", "tsx", path.resolve("src/workers/rabbit-worker.ts")];
    const child = spawn(cmd, args, { env, stdio: "ignore", detached: true });
    const proc: WorkerProc = { pid: child.pid!, started_ts: Date.now(), dest, env: env as Record<string,string> };
    if (!this.state.groups[dest]) this.state.groups[dest] = []; this.state.groups[dest].push(proc);
    child.on("exit", () => { this.state.groups[dest] = (this.state.groups[dest] ?? []).filter(p => p.pid !== child.pid); if (this.state.autorestart) setTimeout(() => this.spawnOne(dest, opts), 500); });
  }
}
export const PM = new WorkerManager();
