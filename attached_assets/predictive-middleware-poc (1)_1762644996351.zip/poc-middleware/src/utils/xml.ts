import { XMLParser, XMLValidator } from "fast-xml-parser";

export function validateXml(xml: string) {
  const valid = XMLValidator.validate(xml);
  if (valid !== true) {
    const err = Array.isArray(valid) ? valid[0] : valid;
    throw new Error(`XML invalid: ${JSON.stringify(err)}`);
  }
}
const parser = new XMLParser({ ignoreAttributes:false, attributeNamePrefix:"@_", parseTagValue:true, trimValues:true });
export function parseXml(xml:string){ return parser.parse(xml); }
