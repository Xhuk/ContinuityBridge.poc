export async function pushWmsHttp(body: unknown) {
  const url = process.env.WMS_HTTP_URL || "";
  if (!url) return;
  const auth = process.env.WMS_HTTP_AUTH || "";
  const timeout = Number(process.env.WMS_HTTP_TIMEOUT_MS || 3000);

  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json", ...(auth ? { "authorization": auth } : {}) },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeout),
  });
  if (!res.ok) {
    const txt = await res.text().catch(()=> "");
    const err = new Error(`WMS ${res.status} ${res.statusText} ${txt}`);
    (err as any).status = res.status;
    throw err;
  }
}
