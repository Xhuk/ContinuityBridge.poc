import express from "express";
import path from "node:path";
import itemsRouter from "./routes/items.js";
import monitorRouter from "./routes/monitor.js";
import pmRouter from "./routes/pm.js";
import fakeWmsRouter from "./routes/fakewms.js";

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/monitor", monitorRouter);
app.use("/pm", pmRouter);
app.use("/fake-wms", fakeWmsRouter);
app.use("/", express.static(path.resolve("public")));
app.use("/items", itemsRouter);

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`server on http://localhost:${port}`));
