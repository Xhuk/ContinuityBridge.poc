# Predictive Middleware POC (Dashboard-managed)

- **Transform-only** IFD (XML) → BYDM (JSON) con **validación real** (fast-xml-parser).
- **Mapping XLSX→BYDM** (coloca `mapping/Item.xlsx`). Endpoint: `GET /items/mapping/status`.
- **RabbitMQ topic** y **workers paralelos** administrados desde el **dashboard**.
- **DLQ + reintentos** por destino (1m, 5m) con TTL + DLX.
- **Fake-WMS** local controlado desde el dashboard (delay y tasa de falla).
- **KPI** (Total, In/Out, últimos 24h, latencias avg/p95) + **export CSV/NDJSON**.

## Requisitos
- Node 20+
- RabbitMQ en localhost:5672 (o ajusta variables de entorno)

## Arranque
```powershell
npm ci
npm run dev
# Dashboard: http://localhost:8080/monitor
```

## Workers (desde el dashboard)
Panel **Control de Workers (POC)** para escalar/ detener; configurar **Prefetch**, **WMS URL/Auth** por destino (`sap`/`3pl`).  
Por defecto, empujan a `http://localhost:8080/fake-wms` (simulado).

## Probar Items inbound
```powershell
Invoke-RestMethod -Method POST -Uri http://localhost:8080/items/ifd?dest=sap `
  -ContentType 'application/json' `
  -Body (@{ xml = (Get-Content -Raw .\item.sample.xml) } | ConvertTo-Json -Compress)
```

## Mapping XLSX
Coloca tu `mapping/Item.xlsx` con columnas: `source_xpath`, `target_path`, `required_json`, `required_xml`.  
Ejemplo de XPaths (IFD):
- PART_INB_IFD.CTRL_SEG.PART_SEG.PRTNUM → item.number
- PART_INB_IFD.CTRL_SEG.PART_SEG.STKUOM → item.uom
- PART_INB_IFD.CTRL_SEG.PART_SEG.RCVSTS → item.status
- PART_INB_IFD.CTRL_SEG.PART_SEG.PART_DESCRIPTION_SEG.SHORT_DSC → item.shortDesc

## Retries / DLQ
Fallos en el worker → reencola con backoff: **1m**, luego **5m**, luego **DLQ** (`items.<dest>.dlq`).  
Las colas de retry usan **x-message-ttl** + **dead-letter** hacia `items.<dest>.upsert`.
